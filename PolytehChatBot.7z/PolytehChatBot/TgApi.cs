﻿
using Newtonsoft.Json;


namespace PolytehChatBot
{
    internal static class TgApi
    {
        private static readonly HttpClient client = new HttpClient();
        private static string TOKEN;



        public static Bot InitializeBot(string token)
        {
            TgApi.TOKEN = token;
            var initialReq = TgApi.TgApiCall("getMe", new Dictionary<string, string>(), true);
            Console.WriteLine(initialReq);

            if (initialReq.Contains("api.telegram.org:443"))
            {
                Console.WriteLine("Проверьте подключение к интернету и повторите попытку\nНажмите кнопку для выхода");
                return null;
            }

            var res = JsonConvert.DeserializeObject<BotInitResponse>(initialReq).Result;
            
            Bot bot = new Bot(TOKEN, res.Id, res.First_Name, res.Username);

            Console.WriteLine($"БОТ [ {bot.Username} - \"{res.First_Name}\" id{res.Id} ] инициализирован");

            return bot;
        }

        public static string TgApiCall(string method, Dictionary<string, string> args,
            bool returnEX = false)
        {
            string url = $"https://api.telegram.org/bot{TOKEN}/{method}?";

            foreach (var arg in args)
                url += $"{arg.Key}={arg.Value}&";

            //if (method != "getUpdates") Console.WriteLine(url);
            
            async Task<string> request()
            {
                try { return await client.GetStringAsync(url); }
                catch (HttpRequestException ex)
                {
                    if (!returnEX) return "0";
                    else return ex.Message;
                }
            }


            return request().Result;

        }



        public static List<Update> GetUpdates(int update_id)
        {

            var response = TgApiCall("getUpdates", new Dictionary<string, string> {
                { "offset", $"{update_id}" },
                {"limit","100" },
                {"timeout","100"},
                {"allowed_updates","[\"message\", \"callback_query\"]" }

            });
            //Console.WriteLine(response);
            var updates = JsonConvert.DeserializeObject<UpdatesResponse>(response);
            return updates?.Result;


        }

        public static void DeleteMessage(string chat_id,string message_id)
        {
            TgApiCall("deleteMessage", new Dictionary<string, string> {
                {"chat_id",$"{chat_id}" },
                { "message_id", $"{message_id}" },
                      },true);
        }

        public static void SendMessage(string chat_id, string text,
            InlineKeyboardMarkup markup = null, bool isHTML = false)
        {
            TgApiCall("sendMessage", new Dictionary<string, string> {
                    { "chat_id", $"{chat_id}" },
                    {"text",Uri.EscapeDataString(text)},
                    {"reply_markup", markup!=null?JsonConvert.SerializeObject(markup):"" },
                    {"parse_mode" , (isHTML?"HTML":"") }
                      });
            
            //Uri.EscapeDataString(
        }

        public static void CopyMessage(string chat_id,string from_chat_id, string message_id)
        {
            TgApiCall("copyMessage", new Dictionary<string, string> {
                    { "chat_id", $"{chat_id}" },
                    { "from_chat_id", $"{from_chat_id}" },
                    { "message_id", $"{message_id}" },
                      });
        }

        public static void AnswerCallbackQuery(string callbackQuery_id, string text)
        {
            TgApiCall("answerCallbackQuery", new Dictionary<string, string>{
                    { "callback_query_id", callbackQuery_id },
                    { "text", text }
                    });
        }

        public static void SendLocation(string chat_id,string latitude, string longitude,
            InlineKeyboardMarkup markup = null)
        {
            TgApiCall("sendLocation", new Dictionary<string, string> {
                    { "chat_id", $"{chat_id}" },
                    { "latitude", $"{latitude}"},
                    { "longitude", $"{longitude}"},
                    {"reply_markup", markup!=null?JsonConvert.SerializeObject(markup):"" },
                      });

        }
        public static async Task SendPhotoAsync(string chat_id, 
            string filepath, string caption = "", 
            InlineKeyboardMarkup markup = null, bool isHTML = false,
            string location = null)
        {
            using (var form = new MultipartFormDataContent())
            using (var fileStream = new FileStream(filepath, FileMode.Open))
            {
                form.Add(new StreamContent(fileStream), "photo", "photo.jpg");

                var response = await client.PostAsync($"https://api.telegram.org/bot{TOKEN}" +
                    $"/sendPhoto?chat_id={chat_id}&caption={caption}" +
                    $"&reply_markup={(markup != null ? JsonConvert.SerializeObject(markup) : "")}" +
                    $"&parse_mode={(isHTML ? "HTML" : "")}", form);
                //Console.WriteLine(await response.Content.ReadAsStringAsync());
            }

        }

        public static async Task SendDocumentAsync(string chat_id,
           string filepath, string caption = "",
           InlineKeyboardMarkup markup = null, bool isHTML = false, string filename = "document.doc")
        {
            using (var form = new MultipartFormDataContent())
            using (var fileStream = new FileStream(filepath, FileMode.Open))
            {
                form.Add(new StreamContent(fileStream), "document", Uri.EscapeDataString(filename));

                var response = await client.PostAsync($"https://api.telegram.org/bot{TOKEN}" +
                    $"/sendDocument?chat_id={chat_id}&caption={caption}" +
                    $"&reply_markup={(markup != null ? JsonConvert.SerializeObject(markup) : "")}" +
                    $"&parse_mode={(isHTML ? "HTML" : "")}", form);
                //Console.WriteLine(await response.Content.ReadAsStringAsync());
            }

        }


    }

    public class BotInitResponse
    {
        public bool Ok { get; set; }
        public Result Result { get; set; }
    }

    public class Result
    {
        public string Id { get; set; }
        public string First_Name { get; set; }
        public string Username { get; set; }
    }

    public class UpdatesResponse
    {
        public List<Update> Result { get; set; }
    }

    public class Update
    {
        public int Update_Id { get; set; }
        public Message Message { get; set; }

        public CallbackQuery Callback_Query { get; set; }
    }

    public class Message
    {
        public int Message_Id { get; set; }
        public Chat Chat { get; set; }
        public string Text { get; set; }
    }

    public class CallbackQuery
    {
        public string Id { get; set; }
        public Message Message { get; set; } 
        public string Data { get; set; } 
        public string ChatId => Message?.Chat?.Id; 
    }



    public class Chat
    {
        public string Id { get; set; }
        public string Type { get; set; }
        public string First_Name { get; set; }
        public string Last_Name { get; set; }
        public string Username { get; set; }
    }

    public class InlineKeyboard
    {
        public List<List<InlineKeyboardButton>> Keyboard { get; set; }

        public InlineKeyboard()
        {
            Keyboard = new List<List<InlineKeyboardButton>>();
        }

        public void AddButton(string text, string callbackData)
        {
            if (Keyboard.Count == 0 || Keyboard[Keyboard.Count - 1].Count >= 2) // max 2 buttons
            {
                Keyboard.Add(new List<InlineKeyboardButton>());
            }

            Keyboard[Keyboard.Count - 1].Add(new InlineKeyboardButton
            {
                text = text,
                callback_data = callbackData
            });
        }

        public void NextRow()
        {
            Keyboard.Add(new List<InlineKeyboardButton>());
        }

        public InlineKeyboardMarkup GetMarkup()
        {
            return new InlineKeyboardMarkup{ inline_keyboard = Keyboard};
        }
    }

    public class InlineKeyboardButton
    {
        public string text { get; set; }
        public string callback_data { get; set; }
    }

    public class InlineKeyboardMarkup
    {
        public List<List<InlineKeyboardButton>> inline_keyboard { get; set; }
    }

}
