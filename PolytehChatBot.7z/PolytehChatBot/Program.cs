﻿

namespace PolytehChatBot
{
    internal class Program
    {
        

        static void Main(string[] args)
        {
            System.Text.Encoding.RegisterProvider(System.Text.CodePagesEncodingProvider.Instance);
            var encoding = System.Text.Encoding.GetEncoding("WINDOWS-1251");

            

            const string TOKEN = "7709402956:AAFkSIPaOyAeUqMlIygl_YnwaMWEVtGx0dg";
           
            Bot bot = TgApi.InitializeBot(TOKEN);
            bot?.StartAsync();
            
            
            Console.ReadLine();


        }

       

    }
}
